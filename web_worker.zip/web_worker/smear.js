function smear(pixels) {
    var data = pixels.data, width = pixels.width, height = pixels.height;
    var n = 10, m = n - 1; // make a bigger for more smearing
    for ( var row = 0; row < height; row++) { // for each row
        var i = row*width*4 + 4; // 2nd pixel offset
        for( var col = 1; col < width; col++, i+=4 ) { // for each col
            data[i] = ( data[i] + data[i-4]*m )/n; // red 
            data[i+1] = ( data[i+1] + data[i-3]*m )/n; // green
            data[i+2] = ( data[i+2] + data[i-2]*m )/n; // blue
            data[i+3] = ( data[i+3] + data[i-1]*m )/n; // alpha
        }
    }
    return pixels;
}
