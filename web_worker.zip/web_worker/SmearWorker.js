importScripts('smear.js');

// Get an ImageData object from the main thread 
onmessage = function(e) { postMessage(smear(e.data)); };
