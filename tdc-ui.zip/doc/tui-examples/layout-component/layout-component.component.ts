import { Component, HostBinding } from '@angular/core';

/**
 * @title Layout with Component
 * @iframe
 */
@Component({
  templateUrl: './layout-component.component.html',
  styleUrls: ['./layout-component.component.css'],
})
export class LayoutComponentComponent {
  @HostBinding('class.tui-layout2') hostClass = true;

  @HostBinding('style.height.vh') height = 100;

  @HostBinding('style.color') color = 'white';
}

@Component({
  selector: 'tui-layout-component-sider',
  template: '<div style="width: 50px; height: 100%; background: red">sider</div>',
})
export class LayoutComponentSiderComponent {
  @HostBinding('class.tui-layout2-sider') siderClass = true;
}

@Component({
  selector: 'tui-layout-component-header',
  template: '<div style="height: 40px; background: blue">header</div>',
})
export class LayoutComponentHeaderComponent {
  @HostBinding('class.tui-layout2-header') headerClass = true;
}

@Component({
  selector: 'tui-layout-component-footer',
  template: '<div style="height: 40px; background: blue">footer</div>',
})
export class LayoutComponentFooterComponent {
  @HostBinding('class.tui-layout2-footer') footerClass = true;
}

@Component({
  selector: 'tui-layout-component-container',
  template: `
    <tui-layout-component-header></tui-layout-component-header>
    <tui-layout-component-content></tui-layout-component-content>
    <tui-layout-component-footer></tui-layout-component-footer>
  `,
})
export class LayoutComponentContainerComponent {
  @HostBinding('class.tui-layout2') hostClass = true;

  @HostBinding('class.vertical') verticalClass = true;

  @HostBinding('style.background') background = 'green';
}


@Component({
  selector: 'tui-layout-component-content',
  template: '<div style="height: 200%; margin: 20px; background: purple">content</div>',
})
export class LayoutComponentContentComponent {
  @HostBinding('class.tui-layout2-content') hostClass = true;
}
