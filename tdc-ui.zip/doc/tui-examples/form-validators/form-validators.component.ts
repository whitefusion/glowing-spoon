import { Component, OnInit } from '@angular/core';

/**
 * @title Custom Form Validators
 */
@Component({
  templateUrl: './form-validators.component.html',
  styleUrls: ['./form-validators.component.css'],
})
export class FormValidatorsComponent implements OnInit {
  ngOnInit() {
  }
}
