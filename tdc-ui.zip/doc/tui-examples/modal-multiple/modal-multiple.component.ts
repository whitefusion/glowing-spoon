import { Component, Injector, Inject, Injectable } from '@angular/core';

import { TuiModalService, TuiModalRef, TUI_MODAL_DATA } from 'tdc-ui';

@Component({
  template: `<button
    style="margin: 8px 20px 8px 0"
    tuiBtn="primary"
    (click)="openChildModal()"
  >Child Modal</button>`,
})
export class ModalMultipleExmapleComponent {
  constructor(
    private modal: TuiModalService,
  ) { }

  openChildModal() {
    this.modal.info({
      title: 'hello',
      message: 'world',
    });
  }

}

/**
 * @title Mutiple Modal
 */
@Component({
  templateUrl: 'modal-multiple.component.html',
  styleUrls: ['modal-multiple.component.css'],
})
export class ModalMultipleComponent {
  constructor(
    private modal: TuiModalService,
    private injector: Injector,
  ) { }

  openMultipleModal() {
    this.modal.open(ModalMultipleExmapleComponent, {
      title: 'Multiple Modal',
      injector: this.injector,
    });
  }
}
