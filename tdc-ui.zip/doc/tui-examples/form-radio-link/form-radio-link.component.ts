import { Component, OnInit } from '@angular/core';

/**
 * @title Radio Link Group
 */
@Component({
  templateUrl: './form-radio-link.component.html',
  styleUrls: ['./form-radio-link.component.css'],
})
export class FormRadioLinkComponent implements OnInit {

  button = 'b1';

  constructor() {

  }

  ngOnInit() {

  }
}
