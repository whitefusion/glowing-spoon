import { Component, OnInit } from '@angular/core';

/**
 * @title Icon List
 */
@Component({
  templateUrl: './icon-overview.component.html',
  styleUrls: ['./icon-overview.component.css'],
})
export class IconOverviewComponent implements OnInit {
  icons: string[] = [];
  statuses = ['RUNNING', 'PREPARING', 'STOPPED', 'DELETED'];

  constructor() { }

  ngOnInit() {
    this.getAllIcon();
  }

  getAllIcon() {
    const iconSymbol = document.querySelector('tui-icon-symbol');
    const symbols = iconSymbol.querySelectorAll('symbol');
    for (let i = 0; i < symbols.length; i ++) {
      this.icons.push(symbols[i].id);
    }
  }

}
