import { CompileComponent } from './compile-component';

import { NgModule } from '@angular/core';

import { CommonModule } from '@angular/common';

@NgModule({
  imports: [CommonModule],
  declarations: [CompileComponent],
  providers: [],
  exports: [CompileComponent],
  entryComponents: [],
})
export class CompileModule {}
