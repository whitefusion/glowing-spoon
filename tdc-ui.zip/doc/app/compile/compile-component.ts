// https://github.com/patrikx3/angular-compile

import { CommonModule } from '@angular/common';
import { parseTemplate } from '@angular/compiler';
import {
  AfterViewInit,
  Compiler,
  Component,
  EventEmitter,
  Injectable,
  Input,
  ModuleWithProviders,
  NgModule,
  NgModuleFactory,
  OnChanges,
  Output,
  SimpleChanges,
  Type,
} from '@angular/core';
import { FormsModule } from '@angular/forms';
import { cloneDeep } from 'lodash';

@Component({
  selector: 'tui-compile',
  template: `
    <ng-container *ngIf="html">
      <ng-container
        *ngComponentOutlet="dynamicComponent; ngModuleFactory: dynamicModule"
      ></ng-container>
    </ng-container>
  `,
})
@Injectable()
export class CompileComponent implements OnChanges {
  @Input() html: string;

  @Input() styles: string;

  @Input() context: any;

  @Input() module: NgModule;

  @Input() imports: Array<Type<any> | ModuleWithProviders<any> | any[]>;

  @Output() compileError = new EventEmitter<Error>();

  dynamicComponent: any;

  dynamicModule: NgModuleFactory<any> | any;

  sourceMapUrl = 'ng:///IconSymbolComponent/template.html';

  interpolationConfig = {
    end: '}}',
    start: '{{',
  };

  constructor(private compiler: Compiler) {}

  static nextId() {
    const randomString = Math.random().toString(36).substring(2);
    return `tui-angular-compile-${randomString}`;
  }

  ngOnChanges(_changes: SimpleChanges) {
    this.update();
  }

  trimHtml(): void {
    if (this.html) {
      this.html = this.html.trim();
    }
  }

  validateTemplate(): boolean {
    const template = parseTemplate(this.html, this.sourceMapUrl, {
      preserveWhitespaces: false,
      interpolationConfig: this.interpolationConfig,
    });

    if (template.errors !== undefined) {
      const errors = template.errors.map((err) => err.toString()).join(', ');
      this.html = `Errors during JIT compilation of template for DynamicComponent: ${errors}`;
      return false;
    }

    return true;
  }

  update() {
    this.trimHtml();

    if (!this.html) {
      this.dynamicComponent = undefined;
      this.dynamicModule = undefined;
      return;
    }

    const valid = this.validateTemplate();

    try {
      this.dynamicComponent = this.createNewComponent(
        this.html,
        this.styles,
        valid,
        this.context,
      );
      this.dynamicModule = this.compiler.compileModuleSync(
        this.createComponentModule(this.dynamicComponent),
      );
    } catch (e) {
      this.compileError.emit(e);
    }
  }

  private createComponentModule(componentType: any) {
    let module: NgModule = {};

    if (this.module !== undefined) {
      module = cloneDeep(this.module);
    }

    module.imports = module.imports || [];
    module.imports.push(CommonModule);
    module.imports.push(FormsModule);

    if (this.imports !== undefined) {
      module.imports = module.imports.concat(this.imports);
    }

    if (module.declarations === undefined) {
      module.declarations = [componentType];
    } else {
      module.declarations.push(componentType);
    }

    // tslint:disable-next-line: deprecation
    module.entryComponents = [componentType];

    @NgModule(module)
    class RuntimeComponentModule {}

    return RuntimeComponentModule;
  }

  private createNewComponent(
    html: string,
    styles: string,
    valid = true,
    context: any,
  ) {
    const id = CompileComponent.nextId();
    const _html = valid ? html : `<div class="compile-error" id="${id}"></div>`;

    @Component({
      selector: id,
      template: _html,
      styles: [styles],
    })
    class DynamicComponent implements AfterViewInit {
      context: any = context;

      ngAfterViewInit() {
        const el = document.getElementById(id);
        if (!valid && el) {
          el.innerText = html;
        }
      }
    }

    return DynamicComponent;
  }
}
