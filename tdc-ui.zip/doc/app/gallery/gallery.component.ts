import { Component } from '@angular/core';

import { TuiTranslateService } from 'tdc-ui';
import autoNavs from '../__auto__/navs';

@Component({
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.sass'],
})
export class GalleryComponent {
  navs = autoNavs.sort();

  langs = [
    'en_US',
    'zh_CN',
  ];
  currentLang: string;

  constructor(public translate: TuiTranslateService) {
    this.currentLang = translate.lang;
  }

  changeLang(lang) {
    this.translate.setLocale(lang);
    this.currentLang = lang;
  }
}
