import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
  TuiModule,
} from 'tdc-ui';

import { GalleryRoutingModule } from './gallery-routing.module';
import { GalleryComponent } from './gallery.component';
import { GaDashboardComponent } from './ga-dashboard/ga-dashboard.component';

/**
 * 子路由组件/模块
 */
import { ComponentViewerComponent } from './component-viewer/component-viewer.component';
import { DocViewerModule } from '../shared/doc-viewer/doc-viewer.module';
import { ApiViewerModule } from '../shared/api-viewer/api-viewer.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    TuiModule,
    GalleryRoutingModule,
    DocViewerModule,
    ApiViewerModule,
  ],
  declarations: [
    GalleryComponent,
    GaDashboardComponent,
    ComponentViewerComponent,
  ],
  providers: [
  ],
  entryComponents: [
  ],
})
export class GalleryModule { }
