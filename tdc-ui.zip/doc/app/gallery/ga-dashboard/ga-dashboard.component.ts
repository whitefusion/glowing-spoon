import { Component } from '@angular/core';

@Component({
  templateUrl: './ga-dashboard.component.html',
})
export class GaDashboardComponent {}
