import {
  Component,
  OnInit,
  Input,
  OnChanges,
} from '@angular/core';
import apis from '../../__auto__/api';

@Component({
  selector: 'tui-api-viewer',
  templateUrl: './api-viewer.component.html',
  styleUrls: ['./api-viewer.component.sass'],
})
export class ApiViewerComponent implements OnInit, OnChanges {

  @Input() example: string;

  apis: any[] = [];

  constructor() { }

  ngOnInit(): void {
  }

  ngOnChanges() {
    if (this.example) {
      this.apis = apis[this.example];
    }
  }
}
