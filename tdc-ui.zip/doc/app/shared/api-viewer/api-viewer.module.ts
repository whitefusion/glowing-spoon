import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {
  TuiModule,
} from 'tdc-ui';

import { ApiViewerComponent } from './api-viewer.component';

@NgModule({
  imports: [
    TuiModule,
    CommonModule,
  ],
  declarations: [
    ApiViewerComponent,
  ],
  exports: [
    ApiViewerComponent,
  ],
})
export class ApiViewerModule { }
