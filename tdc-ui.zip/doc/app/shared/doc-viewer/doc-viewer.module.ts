import { PortalModule } from '@angular/cdk/portal';
import { CdkTreeModule } from '@angular/cdk/tree';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import {
  TuiModule,
} from 'tdc-ui';

import { ExampleViewerComponent } from './example-viewer/example-viewer.component';
import { DocViewerComponent } from './doc-viewer.component';
import { FrameWindowComponent } from './frame-window/frame-window.component';

import { CopierService } from '../copier/copier.service';
import { CompileModule } from 'app/compile';


// ExampleViewer is included in the DocViewerModule because they have a circular dependency.
@NgModule({
  imports: [
    TuiModule,
    CommonModule,
    PortalModule,
    CdkTreeModule,
    CompileModule,
  ],
  providers: [CopierService],
  declarations: [DocViewerComponent, ExampleViewerComponent, FrameWindowComponent],
  entryComponents: [ExampleViewerComponent],
  exports: [DocViewerComponent, ExampleViewerComponent, FrameWindowComponent],
})
export class DocViewerModule { }
