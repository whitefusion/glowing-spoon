import { ComponentPortal } from '@angular/cdk/portal';
import { HttpClient } from '@angular/common/http';
import { Component, Input } from '@angular/core';
import { CompileComponent } from 'app/compile';
import { TuiMessageService, TuiModule } from 'tdc-ui';
import {
  EXAMPLE_COMPONENTS,
  LiveExample,
} from '../../../__auto__/examples-module';
import { CopierService } from '../../copier/copier.service';

@Component({
  selector: 'tui-example-viewer',
  templateUrl: './example-viewer.component.html',
  styleUrls: ['./example-viewer.component.sass'],
})
export class ExampleViewerComponent {
  /** Component portal for the currently displayed example. */
  selectedPortal: ComponentPortal<any>;

  /** String key of the currently displayed example. */
  _example: string;

  exampleData: LiveExample;

  /** Whether the source for the example is being displayed. */
  showSource = false;

  extensions = ['HTML', 'TS', 'CSS'];

  codes = [];

  id: string;

  editing = false;

  dataModule: any = {
    imports: [
      TuiModule,
    ],
    exports: [],
  };

  constructor(
    private copier: CopierService,
    private message: TuiMessageService,
    private _http: HttpClient,
  ) {
    this.id = CompileComponent.nextId();
  }

  get example() {
    return this._example;
  }

  get preWidth() {
    // 480 = nav + toc + padding
    return window.innerWidth - 480 + 'px';
  }

  @Input()
  set example(example: string) {
    if (example && EXAMPLE_COMPONENTS[example]) {
      this._example = example;
      this.fetchCodes();
      this.exampleData = EXAMPLE_COMPONENTS[example];
      this.selectedPortal = new ComponentPortal(this.exampleData.component);
    } else {
      console.log('MISSING EXAMPLE: ', example);
    }
  }

  fetchCodes() {
    this.codes = [];
    this.extensions.forEach((extension) => {
      this._http
        .get(this.exampleFileUrl(extension), { responseType: 'text' })
        .subscribe((response) => {
          const div = document.createElement('div');
          div.innerHTML = response;
          this.codes.push(div.innerText);
        });
    });
  }

  toggleSourceView(): void {
    this.showSource = !this.showSource;
  }

  exampleFileUrl(extension: string) {
    return `/assets/examples/${
      this.example
    }.component-${extension.toLowerCase()}.html`;
  }

  copySource(text: string) {
    if (this.copier.copyText(text)) {
      this.message.success('Code copied');
    } else {
      this.message.error('Copy failed. Please try again!');
    }
  }

  getEditingCodes() {
    this.editing = true;
    this.codes = this.extensions.map((kind, index) => {
      const el = document.getElementById(this.id + '-' + kind);

      if (el) {
        return el.innerText;
      }

      return this.codes[index];
    });
  }

  handleCompileErrorHandler(error: Error) {
    console.log('compile error: ', error);
    this.codes[0] = error;
  }
}
