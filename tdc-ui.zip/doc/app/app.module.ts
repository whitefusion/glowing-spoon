import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, Inject } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { TuiModule } from 'tdc-ui';

import { AppComponent } from './app.component';
import { GalleryModule } from './gallery/gallery.module';
import { DocViewerModule } from './shared/doc-viewer/doc-viewer.module';
import { ExampleModule } from './__auto__/examples-module';

@NgModule({
  imports: [
    RouterModule.forRoot([
      {
        path: '',
        redirectTo: '/gallery',
        pathMatch: 'full',
      },
    ], {useHash: false}),
  ],
  exports: [
    RouterModule,
  ],
})
export class AppRoutingModule { }

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    TuiModule,
    GalleryModule,
    AppRoutingModule,
    ExampleModule,
    DocViewerModule,
    HttpClientModule,
  ],
  declarations: [
    AppComponent,
  ],
  providers: [
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
