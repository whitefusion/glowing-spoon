
/* tslint:disable */
/** DO NOT MANUALLY EDIT THIS FILE, IT IS GENERATED VIA GULP 'build-examples-module' */
import {NgModule} from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
// import {ExampleMaterialModule} from './material-module';
import {
  TuiModule,
} from 'tdc-ui';
import {AvatarIconsComponent} from '../../tui-examples/avatar-icons/avatar-icons.component';
import {AvatarImagesComponent} from '../../tui-examples/avatar-images/avatar-images.component';
import {AvatarOverviewComponent} from '../../tui-examples/avatar-overview/avatar-overview.component';
import {AvatarTextComponent} from '../../tui-examples/avatar-text/avatar-text.component';
import {BreadcrumbOverviewComponent} from '../../tui-examples/breadcrumb-overview/breadcrumb-overview.component';
import {ButtonDefaultComponent} from '../../tui-examples/button-default/button-default.component';
import {ButtonDisabledComponent} from '../../tui-examples/button-disabled/button-disabled.component';
import {ButtonGroupComponent} from '../../tui-examples/button-group/button-group.component';
import {ButtonLoadingComponent} from '../../tui-examples/button-loading/button-loading.component';
import {ButtonOutlinedComponent} from '../../tui-examples/button-outlined/button-outlined.component';
import {ButtonSizeComponent} from '../../tui-examples/button-size/button-size.component';
import {CarouselOverviewComponent} from '../../tui-examples/carousel-overview/carousel-overview.component';
import {DatepickerLiteOverviewComponent} from '../../tui-examples/datepicker-lite-overview/datepicker-lite-overview.component';
import {DatepickerOverviewComponent} from '../../tui-examples/datepicker-overview/datepicker-overview.component';
import {DropdownCaretComponent} from '../../tui-examples/dropdown-caret/dropdown-caret.component';
import {DropdownContextComponent} from '../../tui-examples/dropdown-context/dropdown-context.component';
import {DropdownDefaultOpenComponent} from '../../tui-examples/dropdown-default-open/dropdown-default-open.component';
import {DropdownDirectionsComponent} from '../../tui-examples/dropdown-directions/dropdown-directions.component';
import {DropdownTitleComponent} from '../../tui-examples/dropdown-title/dropdown-title.component';
import {FilteringOverviewComponent} from '../../tui-examples/filtering-overview/filtering-overview.component';
import {FormItemComponent} from '../../tui-examples/form-item/form-item.component';
import {FormOverviewComponent} from '../../tui-examples/form-overview/form-overview.component';
import {FormRadioBtnComponent} from '../../tui-examples/form-radio-btn/form-radio-btn.component';
import {FormRadioLinkComponent} from '../../tui-examples/form-radio-link/form-radio-link.component';
import {FormValidatorsComponent} from '../../tui-examples/form-validators/form-validators.component';
import {FormValueComponent} from '../../tui-examples/form-value/form-value.component';
import {IconOverviewComponent} from '../../tui-examples/icon-overview/icon-overview.component';
import {InputOverviewComponent} from '../../tui-examples/input-overview/input-overview.component';
import {LayoutComponentSiderComponent,LayoutComponentHeaderComponent,LayoutComponentFooterComponent,LayoutComponentContainerComponent,LayoutComponentContentComponent,LayoutComponentComponent} from '../../tui-examples/layout-component/layout-component.component';
import {LayoutOverviewComponent} from '../../tui-examples/layout-overview/layout-overview.component';
import {LoadingOverviewComponent} from '../../tui-examples/loading-overview/loading-overview.component';
import {LoadingTabComponent} from '../../tui-examples/loading-tab/loading-tab.component';
import {MenuAvatarComponent} from '../../tui-examples/menu-avatar/menu-avatar.component';
import {MenuComplicatedComponent} from '../../tui-examples/menu-complicated/menu-complicated.component';
import {MenuCustomComponent} from '../../tui-examples/menu-custom/menu-custom.component';
import {MenuOverviewComponent} from '../../tui-examples/menu-overview/menu-overview.component';
import {MenuRouteComponent} from '../../tui-examples/menu-route/menu-route.component';
import {MessageOverviewComponent} from '../../tui-examples/message-overview/message-overview.component';
import {ModalWithCloseCallbackComponent,ModalClosecallbackComponent} from '../../tui-examples/modal-closecallback/modal-closecallback.component';
import {ModalConfirmComponent} from '../../tui-examples/modal-confirm/modal-confirm.component';
import {ModalWithDataComponent,ModalDataComponent} from '../../tui-examples/modal-data/modal-data.component';
import {ModalWithInjectorComponent,ModalInjectorComponent} from '../../tui-examples/modal-injector/modal-injector.component';
import {ModalMultipleExmapleComponent,ModalMultipleComponent} from '../../tui-examples/modal-multiple/modal-multiple.component';
import {ModalHelloComponent,ModalOverviewComponent} from '../../tui-examples/modal-overview/modal-overview.component';
import {ModalScrollableComponent,ModalScrollComponent} from '../../tui-examples/modal-scroll/modal-scroll.component';
import {ModalTipComponent} from '../../tui-examples/modal-tip/modal-tip.component';
import {PaginationOverviewComponent} from '../../tui-examples/pagination-overview/pagination-overview.component';
import {PaginationSizesComponent} from '../../tui-examples/pagination-sizes/pagination-sizes.component';
import {PopoverContentComponent} from '../../tui-examples/popover-content/popover-content.component';
import {PopoverOverviewComponent} from '../../tui-examples/popover-overview/popover-overview.component';
import {ProgressDefaultComponent} from '../../tui-examples/progress-default/progress-default.componet';
import {PromptOverviewComponent} from '../../tui-examples/prompt-overview/prompt-overview.component';
import {PropertyCustomComponent} from '../../tui-examples/property-custom/property-custom.component';
import {PropertyOverviewComponent} from '../../tui-examples/property-overview/property-overview.component';
import {SelectFormComponent} from '../../tui-examples/select-form/select-form.component';
import {SelectMultipleComponent} from '../../tui-examples/select-multiple/select-multiple.component';
import {SelectNoneComponent} from '../../tui-examples/select-none/select-none.component';
import {SelectOverviewComponent} from '../../tui-examples/select-overview/select-overview.component';
import {SelectSearchComponent} from '../../tui-examples/select-search/select-search.component';
import {SelectStringComponent} from '../../tui-examples/select-string/select-string.component';
import {SelectTopComponent} from '../../tui-examples/select-top/select-top.component';
import {StepsOverviewComponent} from '../../tui-examples/steps-overview/steps-overview.component';
import {SubmenuOverviewComponent} from '../../tui-examples/submenu-overview/submenu-overview.component';
import {TabAsyncComponent} from '../../tui-examples/tab-async/tab-async.component';
import {TabCardComponent} from '../../tui-examples/tab-card/tab-card.component';
import {TabInoutputComponent} from '../../tui-examples/tab-Inoutput/tab-inoutput.component';
import {TabOverviewComponent} from '../../tui-examples/tab-overview/tab-overview.component';
import {TabPreserveWorldComponent,TabPreserveComponent} from '../../tui-examples/tab-preserve/tab-preserve.component';
import {TabTemplateComponent} from '../../tui-examples/tab-template/tab-template.component';
import {TableCheckboxOperationComponent,TableCheckboxComponent} from '../../tui-examples/table-checkbox/table-checkbox.component';
import {TableEmptyComponent} from '../../tui-examples/table-empty/table-empty.component';
import {TableLoadingComponent} from '../../tui-examples/table-loading/table-loading.component';
import {TableNestingIdComponent,TableNestingSublistComponent,TableNestingComponent} from '../../tui-examples/table-nesting/table-nesting.component';
import {TableOutlinedComponent} from '../../tui-examples/table-outlined/table-outlined.component';
import {TableScrollComponent} from '../../tui-examples/table-scroll/table-scroll.component';
import {TableSortComponent} from '../../tui-examples/table-sort/table-sort.component';
import {TimepickerOverviewComponent} from '../../tui-examples/timepicker-overview/timepicker-overview.component';
import {TooltipOverviewComponent} from '../../tui-examples/tooltip-overview/tooltip-overview.component';
import {TreeBasicComponent} from '../../tui-examples/tree-basic/tree-basic.component';
import {TreeFinderComponent} from '../../tui-examples/tree-finder/tree-finder.component';
import {TreeLazyLoadComponent} from '../../tui-examples/tree-lazy-load/tree-lazy-load.component';
import {TreeSelectionComponent} from '../../tui-examples/tree-selection/tree-selection.component';
import {UploadErrorComponent} from '../../tui-examples/upload-error/upload-error.component';
import {UploadFilesizeComponent} from '../../tui-examples/upload-filesize/upload-filesize.component';
import {UploadFiletypeComponent} from '../../tui-examples/upload-filetype/upload-filetype.component';
import {UploadOverviewComponent} from '../../tui-examples/upload-overview/upload-overview.component';
import {UploadTextfileComponent} from '../../tui-examples/upload-textfile/upload-textfile.component';

export interface LiveExample {
  title: string;
  component: any;
  iframe?: boolean;
  additionalFiles?: string[];
  selectorName?: string;
}

export const EXAMPLE_COMPONENTS: {[key: string]: LiveExample} = {
  'avatar-icons': {
    title: 'Avatar icons',
    component: AvatarIconsComponent
  },
  'avatar-images': {
    title: 'Avatar Images',
    component: AvatarImagesComponent
  },
  'avatar-overview': {
    title: 'Basic Avatar',
    component: AvatarOverviewComponent
  },
  'avatar-text': {
    title: 'Avatar Text',
    component: AvatarTextComponent
  },
  'breadcrumb-overview': {
    title: 'Basic Breadcrumb',
    component: BreadcrumbOverviewComponent
  },
  'button-default': {
    title: 'Default Button',
    component: ButtonDefaultComponent
  },
  'button-disabled': {
    title: 'Disabled Button',
    component: ButtonDisabledComponent
  },
  'button-group': {
    title: 'Button Group',
    component: ButtonGroupComponent
  },
  'button-loading': {
    title: 'Button Loading',
    component: ButtonLoadingComponent
  },
  'button-outlined': {
    title: 'Outlined Button',
    component: ButtonOutlinedComponent
  },
  'button-size': {
    title: 'Different Size Button',
    component: ButtonSizeComponent
  },
  'carousel-overview': {
    title: 'Carousel Overview',
    component: CarouselOverviewComponent
  },
  'datepicker-lite-overview': {
    title: 'Datepicker Lite Overview',
    component: DatepickerLiteOverviewComponent
  },
  'datepicker-overview': {
    title: 'Datepicker Overview',
    component: DatepickerOverviewComponent
  },
  'dropdown-caret': {
    title: 'Dropdown Caret',
    component: DropdownCaretComponent
  },
  'dropdown-context': {
    title: 'Dropdown context menu',
    component: DropdownContextComponent
  },
  'dropdown-default-open': {
    title: 'Dropdown default open',
    component: DropdownDefaultOpenComponent
  },
  'dropdown-directions': {
    title: 'Dropdown Directions',
    component: DropdownDirectionsComponent
  },
  'dropdown-title': {
    title: 'Dropdown with title',
    component: DropdownTitleComponent
  },
  'filtering-overview': {
    title: 'Filtering Overview',
    component: FilteringOverviewComponent
  },
  'form-item': {
    title: 'Form Item',
    component: FormItemComponent
  },
  'form-overview': {
    title: 'Regular Form',
    component: FormOverviewComponent
  },
  'form-radio-btn': {
    title: 'Radio Button Group',
    component: FormRadioBtnComponent
  },
  'form-radio-link': {
    title: 'Radio Link Group',
    component: FormRadioLinkComponent
  },
  'form-validators': {
    title: 'Custom Form Validators',
    component: FormValidatorsComponent
  },
  'form-value': {
    title: 'Form with Default Value',
    component: FormValueComponent
  },
  'icon-overview': {
    title: 'Icon List',
    component: IconOverviewComponent
  },
  'input-overview': {
    title: 'Basic Input',
    component: InputOverviewComponent
  },
  'layout-component': {
    title: 'Layout with Component',
    component: LayoutComponentComponent,
    iframe: true,
    additionalFiles: [null,null,null,null,null],
    selectorName: 'LayoutComponentComponent, LayoutComponentSiderComponent, LayoutComponentHeaderComponent, LayoutComponentFooterComponent, LayoutComponentContainerComponent, LayoutComponentContentComponent'
  },
  'layout-overview': {
    title: 'Layout Overview',
    component: LayoutOverviewComponent,
    iframe: true
  },
  'loading-overview': {
    title: 'Basic Loading',
    component: LoadingOverviewComponent
  },
  'loading-tab': {
    title: 'Tab Loading',
    component: LoadingTabComponent
  },
  'menu-avatar': {
    title: 'Menu Avatar',
    component: MenuAvatarComponent
  },
  'menu-complicated': {
    title: 'Complicated Menu',
    component: MenuComplicatedComponent
  },
  'menu-custom': {
    title: 'Menu Custom',
    component: MenuCustomComponent
  },
  'menu-overview': {
    title: 'Menu Overview',
    component: MenuOverviewComponent
  },
  'menu-route': {
    title: 'Menu Route',
    component: MenuRouteComponent
  },
  'message-overview': {
    title: 'Message Overview',
    component: MessageOverviewComponent
  },
  'modal-closecallback': {
    title: 'Modal Close Callback',
    component: ModalClosecallbackComponent,
    additionalFiles: [null],
    selectorName: 'ModalClosecallbackComponent, ModalWithCloseCallbackComponent'
  },
  'modal-confirm': {
    title: 'Modal Confirm',
    component: ModalConfirmComponent
  },
  'modal-data': {
    title: 'Modal Data',
    component: ModalDataComponent,
    additionalFiles: [null],
    selectorName: 'ModalDataComponent, ModalWithDataComponent'
  },
  'modal-injector': {
    title: 'Modal Injector',
    component: ModalInjectorComponent,
    additionalFiles: [null],
    selectorName: 'ModalInjectorComponent, ModalWithInjectorComponent'
  },
  'modal-multiple': {
    title: 'Mutiple Modal',
    component: ModalMultipleComponent,
    additionalFiles: [null],
    selectorName: 'ModalMultipleComponent, ModalMultipleExmapleComponent'
  },
  'modal-overview': {
    title: 'Modal Overview',
    component: ModalOverviewComponent,
    additionalFiles: [null],
    selectorName: 'ModalOverviewComponent, ModalHelloComponent'
  },
  'modal-scroll': {
    title: 'Modal Scroll',
    component: ModalScrollComponent,
    additionalFiles: [null],
    selectorName: 'ModalScrollComponent, ModalScrollableComponent'
  },
  'modal-tip': {
    title: 'Model Tip',
    component: ModalTipComponent
  },
  'pagination-overview': {
    title: 'Pagination Overview',
    component: PaginationOverviewComponent
  },
  'pagination-sizes': {
    title: 'Pagination Sizes',
    component: PaginationSizesComponent
  },
  'popover-content': {
    title: 'Popover Content',
    component: PopoverContentComponent
  },
  'popover-overview': {
    title: 'Popover Overview',
    component: PopoverOverviewComponent
  },
  'progress-default': {
    title: 'Simple Progress',
    component: ProgressDefaultComponent
  },
  'prompt-overview': {
    title: 'Prompt Overview',
    component: PromptOverviewComponent
  },
  'property-custom': {
    title: 'Property Custom',
    component: PropertyCustomComponent
  },
  'property-overview': {
    title: 'Property Overview',
    component: PropertyOverviewComponent
  },
  'select-form': {
    title: 'Form',
    component: SelectFormComponent
  },
  'select-multiple': {
    title: 'Multiple Select',
    component: SelectMultipleComponent
  },
  'select-none': {
    title: 'Select with No Options',
    component: SelectNoneComponent
  },
  'select-overview': {
    title: 'Object Options',
    component: SelectOverviewComponent
  },
  'select-search': {
    title: 'Select with Search',
    component: SelectSearchComponent
  },
  'select-string': {
    title: 'String Options',
    component: SelectStringComponent
  },
  'select-top': {
    title: 'Direction Top',
    component: SelectTopComponent
  },
  'steps-overview': {
    title: 'simple steps',
    component: StepsOverviewComponent
  },
  'submenu-overview': {
    title: 'Submenu Overview',
    component: SubmenuOverviewComponent
  },
  'tab-async': {
    title: 'Async Tab',
    component: TabAsyncComponent
  },
  'tab-card': {
    title: 'Card type',
    component: TabCardComponent
  },
  'tab-inoutput': {
    title: 'Selected Index Input & Output',
    component: TabInoutputComponent
  },
  'tab-overview': {
    title: 'Basic Tab',
    component: TabOverviewComponent
  },
  'tab-preserve': {
    title: 'Preserve tab content',
    component: TabPreserveComponent,
    additionalFiles: [null],
    selectorName: 'TabPreserveComponent, TabPreserveWorldComponent'
  },
  'tab-template': {
    title: 'Template Tab',
    component: TabTemplateComponent
  },
  'table-checkbox': {
    title: 'Table with Checkbox',
    component: TableCheckboxComponent,
    additionalFiles: [null],
    selectorName: 'TableCheckboxComponent, TableCheckboxOperationComponent'
  },
  'table-empty': {
    title: 'Empty Table',
    component: TableEmptyComponent
  },
  'table-loading': {
    title: 'Table with Checkbox',
    component: TableLoadingComponent
  },
  'table-nesting': {
    title: 'Nesting Table',
    component: TableNestingComponent,
    additionalFiles: [null,null],
    selectorName: 'TableNestingComponent, TableNestingIdComponent, TableNestingSublistComponent'
  },
  'table-outlined': {
    title: 'Table outline',
    component: TableOutlinedComponent
  },
  'table-scroll': {
    title: 'Scrollable Table',
    component: TableScrollComponent
  },
  'table-sort': {
    title: 'Table sort',
    component: TableSortComponent
  },
  'timepicker-overview': {
    title: 'Timepicker Overview',
    component: TimepickerOverviewComponent
  },
  'tooltip-overview': {
    title: 'Tooltip Overview',
    component: TooltipOverviewComponent
  },
  'tree-basic': {
    title: 'Tree Basic',
    component: TreeBasicComponent
  },
  'tree-finder': {
    title: 'Finder Tree',
    component: TreeFinderComponent
  },
  'tree-lazy-load': {
    title: 'Tree Lazy Load',
    component: TreeLazyLoadComponent
  },
  'tree-selection': {
    title: 'Tree Select',
    component: TreeSelectionComponent
  },
  'upload-error': {
    title: 'Upload Error',
    component: UploadErrorComponent
  },
  'upload-filesize': {
    title: 'Upload Filesize',
    component: UploadFilesizeComponent
  },
  'upload-filetype': {
    title: 'Upload Filetype',
    component: UploadFiletypeComponent
  },
  'upload-overview': {
    title: 'Upload Overview',
    component: UploadOverviewComponent
  },
  'upload-textfile': {
    title: 'Upload Text File',
    component: UploadTextfileComponent
  },
};

export const EXAMPLE_LIST = [
  AvatarIconsComponent,
  AvatarImagesComponent,
  AvatarOverviewComponent,
  AvatarTextComponent,
  BreadcrumbOverviewComponent,
  ButtonDefaultComponent,
  ButtonDisabledComponent,
  ButtonGroupComponent,
  ButtonLoadingComponent,
  ButtonOutlinedComponent,
  ButtonSizeComponent,
  CarouselOverviewComponent,
  DatepickerLiteOverviewComponent,
  DatepickerOverviewComponent,
  DropdownCaretComponent,
  DropdownContextComponent,
  DropdownDefaultOpenComponent,
  DropdownDirectionsComponent,
  DropdownTitleComponent,
  FilteringOverviewComponent,
  FormItemComponent,
  FormOverviewComponent,
  FormRadioBtnComponent,
  FormRadioLinkComponent,
  FormValidatorsComponent,
  FormValueComponent,
  IconOverviewComponent,
  InputOverviewComponent,
  LayoutComponentSiderComponent,LayoutComponentHeaderComponent,LayoutComponentFooterComponent,LayoutComponentContainerComponent,LayoutComponentContentComponent,LayoutComponentComponent,
  LayoutOverviewComponent,
  LoadingOverviewComponent,
  LoadingTabComponent,
  MenuAvatarComponent,
  MenuComplicatedComponent,
  MenuCustomComponent,
  MenuOverviewComponent,
  MenuRouteComponent,
  MessageOverviewComponent,
  ModalWithCloseCallbackComponent,ModalClosecallbackComponent,
  ModalConfirmComponent,
  ModalWithDataComponent,ModalDataComponent,
  ModalWithInjectorComponent,ModalInjectorComponent,
  ModalMultipleExmapleComponent,ModalMultipleComponent,
  ModalHelloComponent,ModalOverviewComponent,
  ModalScrollableComponent,ModalScrollComponent,
  ModalTipComponent,
  PaginationOverviewComponent,
  PaginationSizesComponent,
  PopoverContentComponent,
  PopoverOverviewComponent,
  ProgressDefaultComponent,
  PromptOverviewComponent,
  PropertyCustomComponent,
  PropertyOverviewComponent,
  SelectFormComponent,
  SelectMultipleComponent,
  SelectNoneComponent,
  SelectOverviewComponent,
  SelectSearchComponent,
  SelectStringComponent,
  SelectTopComponent,
  StepsOverviewComponent,
  SubmenuOverviewComponent,
  TabAsyncComponent,
  TabCardComponent,
  TabInoutputComponent,
  TabOverviewComponent,
  TabPreserveWorldComponent,TabPreserveComponent,
  TabTemplateComponent,
  TableCheckboxOperationComponent,TableCheckboxComponent,
  TableEmptyComponent,
  TableLoadingComponent,
  TableNestingIdComponent,TableNestingSublistComponent,TableNestingComponent,
  TableOutlinedComponent,
  TableScrollComponent,
  TableSortComponent,
  TimepickerOverviewComponent,
  TooltipOverviewComponent,
  TreeBasicComponent,
  TreeFinderComponent,
  TreeLazyLoadComponent,
  TreeSelectionComponent,
  UploadErrorComponent,
  UploadFilesizeComponent,
  UploadFiletypeComponent,
  UploadOverviewComponent,
  UploadTextfileComponent,
];

@NgModule({
  declarations: EXAMPLE_LIST,
  entryComponents: EXAMPLE_LIST,
  imports: [
    // ExampleMaterialModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    TuiModule,
  ]
})
export class ExampleModule { }
