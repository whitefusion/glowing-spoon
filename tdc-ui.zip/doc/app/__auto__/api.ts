export default {
  "avatar": [
    {
      "name": "avatar.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "text",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "src",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "icon",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "size",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "breadcrumb": [
    {
      "name": "breadcrumb-item.component",
      "apis": []
    },
    {
      "name": "breadcrumb.component",
      "apis": []
    }
  ],
  "btn": [
    {
      "name": "btn-outline.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiBtnOutline",
          "type": "BooleanKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "btn.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiBtn",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "size",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "tuiBtnIcon",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "tuiBtnLoading",
          "type": "BooleanKeyword",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "carousel": [
    {
      "name": "carousel-content.directive",
      "apis": []
    },
    {
      "name": "carousel.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "loading",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showDots",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showNav",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showPlaceholder",
          "type": "",
          "optional": false
        }
      ]
    }
  ],
  "datepicker": [
    {
      "name": "calendar.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "startAt",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "startView",
          "type": "UnionType",
          "default": "month",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "selected",
          "type": "UnionType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "minDate",
          "type": "UnionType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "maxDate",
          "type": "UnionType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showTime",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "format",
          "type": "",
          "default": "yyyy/MM/dd",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "dateFilter",
          "type": "FunctionType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "selectedChange",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "userSelection",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "calendar-body.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "label",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "view",
          "type": "UnionType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "rows",
          "type": "ArrayType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "todayValue",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "selectedValue",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "labelMinRequiredCells",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "numCols",
          "type": "",
          "default": "7",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "allowDisabledSelection",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "activeCell",
          "type": "",
          "default": "0",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "cellAspectRatio",
          "type": "",
          "default": "1",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "selectedValueChange",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "datepicker-input.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "placeholder",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "errorMsgs",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "max",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "min",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showTime",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "format",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "datepicker",
          "type": "TypeReference",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "datepicker.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "startAt",
          "type": "UnionType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "startView",
          "type": "UnionType",
          "default": "month",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "disabled",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "selectedChanged",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "month-view.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "activeDate",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "selected",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "dateFilter",
          "type": "FunctionType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showTime",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "format",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "selectedChange",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "userSelection",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "year-view.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "activeDate",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "selected",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "dateFilter",
          "type": "FunctionType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "format",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "selectedChange",
          "type": "",
          "optional": false
        }
      ]
    }
  ],
  "datepicker-lite": [
    {
      "name": "datepicker-lite-content.directive",
      "apis": []
    },
    {
      "name": "datepicker-lite.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "showTime",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "format",
          "type": "",
          "default": "yyyy-MM-dd HH:mm",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "required",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "placeholder",
          "type": "",
          "default": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "placement",
          "type": "TypeReference",
          "default": "bottomLeft",
          "optional": false
        }
      ]
    }
  ],
  "dropdown": [
    {
      "name": "dropdown-item.component",
      "apis": []
    },
    {
      "name": "dropdown-title.component",
      "apis": []
    },
    {
      "name": "dropdown-trigger.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "dropdown",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "tuiDropdownVisible",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "dropdown.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "direction",
          "type": "TypeReference",
          "default": "bottom",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "caret",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "trigger",
          "type": "UnionType",
          "default": "click",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "customClass",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "clickHide",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "open",
          "type": "BooleanKeyword",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "form": [
    {
      "name": "checkbox.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "halfSelected",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "compel.directive",
      "apis": []
    },
    {
      "name": "checkbox-group.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "errorMsgs",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "checkbox-item.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "checkboxValue",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "form-error.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "validationResults",
          "type": "ArrayType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "errorMsgs",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "form-item-addon.directive",
      "apis": []
    },
    {
      "name": "form-item-text.directive",
      "apis": []
    },
    {
      "name": "form-item.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "label",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "labelFlex",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "inputFlex",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "form.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "labelFlex",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "inputFlex",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "input.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "prefix",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "suffix",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "placeholder",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "type",
          "type": "",
          "default": "text",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "errorMsgs",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "blur",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "input-number.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "placeholder",
          "type": "",
          "default": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "tuiMinValue",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "tuiMaxValue",
          "type": "",
          "default": "Infinity",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "errorMsgs",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "step",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "radio-btn-group.directive",
      "apis": []
    },
    {
      "name": "radio-group.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "errorMsgs",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "name",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "radio-link-group.directive",
      "apis": []
    },
    {
      "name": "radio-item.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "radioValue",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "switch.component",
      "apis": []
    },
    {
      "name": "textarea.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "placeholder",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "errorMsgs",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "rows",
          "type": "",
          "default": "4",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "maxlength",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "resizeVertical",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "equal.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiEqual",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "tuiEqualPassword",
          "type": "",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "max-value.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiMaxValue",
          "type": "",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "min-value.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiMinValue",
          "type": "",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "icon": [
    {
      "name": "icon-symbol.component",
      "apis": []
    },
    {
      "name": "icon.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiIcon",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "color",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "size",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "layout": [],
  "loading": [
    {
      "name": "loading.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiLoading",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "tuiLoadingHeight",
          "type": "",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "menu": [
    {
      "name": "menu-item-group.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "menuTitle",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "menu-item.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "icon",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "key",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "avatarText",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "menuItemTemplate",
          "type": "TypeReference",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "menu.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "selectedKey",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "routeHandler",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "initCollapse",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "mode",
          "type": "TypeReference",
          "default": "float",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "menuTitle",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "menuHeadTemplate",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "menuTemplate",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "collapsedChange",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "selectChange",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "openChange",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "sub-menu.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "icon",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "avatarText",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "background",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "menuTitle",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "menuTitleTemplate",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "alignTo",
          "type": "TypeLiteral",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "key",
          "type": "",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "message": [
    {
      "name": "message-container.component",
      "apis": []
    },
    {
      "name": "message.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "message",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "index",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "modal": [
    {
      "name": "modal-confirm.component",
      "apis": []
    },
    {
      "name": "modal-container.component",
      "apis": []
    },
    {
      "name": "modal-foot.component",
      "apis": []
    },
    {
      "name": "modal-tip.component",
      "apis": []
    }
  ],
  "pagination": [
    {
      "name": "pagination.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "pagination",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showTotal",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showSize",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showGoTo",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "sizes",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "paginationChange",
          "type": "",
          "optional": false
        }
      ]
    }
  ],
  "popover": [
    {
      "name": "popover.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "placement",
          "type": "TypeReference",
          "default": "top",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "trigger",
          "type": "UnionType",
          "default": "hover",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "customClass",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "popover.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "popover",
          "type": "TypeReference",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "progress": [
    {
      "name": "progress.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "percent",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "status",
          "type": "",
          "default": "active",
          "optional": false
        }
      ]
    }
  ],
  "prompt": [
    {
      "name": "prompt.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "type",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "property": [
    {
      "name": "property.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "icon",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "label",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "value",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "color",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "link",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "select": [
    {
      "name": "select-option-all.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "disabled",
          "type": "BooleanKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "select-option-item.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "selectOption",
          "type": "TypeReference",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "select-option.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "value",
          "type": "AnyKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "label",
          "type": "AnyKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "disabled",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "select.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "placeholder",
          "type": "",
          "default": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "searchKey",
          "type": "",
          "default": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "direction",
          "type": "UnionType",
          "default": "bottom",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "disabled",
          "type": "AnyKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "readonly",
          "type": "AnyKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "allowSearch",
          "type": "AnyKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "allowClear",
          "type": "AnyKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "mode",
          "type": "TypeReference",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "steps": [
    {
      "name": "step-item.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "currentIndex",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "steps.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "current",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "submenu": [
    {
      "name": "submenu-list.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "items",
          "type": "ArrayType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "menuTitle",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "submenu.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "backUrl",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "tab": [
    {
      "name": "tab-pane.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "title",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "titleTemplate",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "key",
          "type": "AnyKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "tuiTabPaneForceReload",
          "type": "BooleanKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "tab.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "selectedIndex",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "type",
          "type": "TypeReference",
          "default": "line",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "selectedIndexChange",
          "type": "",
          "optional": false
        }
      ]
    }
  ],
  "table": [
    {
      "name": "table-head-cell.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "sortKey",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "sortOrder",
          "type": "TypeReference",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "table-head.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "selectedKey",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "sortMode",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "sortChange",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "table-outline.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiTableOutline",
          "type": "BooleanKeyword",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "table-row.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiTableRowDatum",
          "type": "",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "table-scroll-body.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "maxHeight",
          "type": "",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "table.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiTableFlex",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "loading",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "tuiTableData",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "tuiTableDataChange",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "selectChange",
          "type": "",
          "optional": false
        }
      ]
    }
  ],
  "timepicker": [
    {
      "name": "timepicker-inner.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "allowHour",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "allowMinute",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "allowSecond",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "timepicker.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "format",
          "type": "",
          "default": "HH:mm:ss",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "allowHour",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "allowMinute",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "allowSecond",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "placement",
          "type": "TypeReference",
          "default": "top",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "selectedChange",
          "type": "",
          "optional": false
        }
      ]
    }
  ],
  "tooltip": [
    {
      "name": "tooltip.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tooltip",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "placement",
          "type": "TypeReference",
          "default": "top",
          "optional": false
        }
      ]
    },
    {
      "name": "tooltip.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tooltip",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "placement",
          "type": "TypeReference",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "tuiTooltipPos",
          "type": "UnionType",
          "default": null,
          "optional": false
        }
      ]
    }
  ],
  "tree": [
    {
      "name": "tree-node-def.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "tuiTreeNodeDefWhen",
          "type": "",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "data",
          "type": "TypeReference",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "tree-node-outlet.directive",
      "apis": []
    },
    {
      "name": "tree-node-toggle.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "recursive",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "tree-node.directive",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "node",
          "type": "TypeReference",
          "default": null,
          "optional": false
        }
      ]
    },
    {
      "name": "tree-select.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "disabled",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "tree.component",
      "apis": [
        {
          "decoratorType": "Output",
          "id": "selectChange",
          "type": "",
          "optional": false
        }
      ]
    }
  ],
  "upload": [
    {
      "name": "upload-btn.component",
      "apis": []
    },
    {
      "name": "upload-list.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "uploadTips",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showUploadTip",
          "type": "",
          "optional": false
        }
      ]
    },
    {
      "name": "upload.component",
      "apis": [
        {
          "decoratorType": "Input",
          "id": "action",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "fileTypes",
          "type": "ArrayType",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "fileSize",
          "type": "NumberKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "fileSizeErrorText",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "fileTypesErrorText",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "uploadTips",
          "type": "StringKeyword",
          "default": null,
          "optional": false
        },
        {
          "decoratorType": "Input",
          "id": "showUploadTip",
          "type": "",
          "optional": false
        },
        {
          "decoratorType": "Output",
          "id": "uploadFileChange",
          "type": "",
          "optional": false
        }
      ]
    }
  ]
}