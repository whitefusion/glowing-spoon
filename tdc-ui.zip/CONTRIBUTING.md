# Contributing to TDC UI

  - [Workflow](#workflow)
  - [Commit Message Guidelines](#commit-message-guidelines)
  - [开发组件](#开发组件)
  - [Gitlab CI](#gitlab-ci)

## Workflow

### 新增特性/修复bug

  - 在jira将相应task assign给自己。从master分支切出自己的分支

    ```
    git checkout -b my-branch master
    ```
  - 添加相应代码和测试，组件开发和测试向导遵从[开发组件](#开发组件)
  - 提交改变，提交message遵从[commit message conventions](#commit)
  - 更新当前分支到gitlab
    ```
    git push origin my-branch
    ```
  - 发送一个merge request到master分支
  - 如果reviewer有改进意见，则修改代码并`rebase`提交
    ```
    git rebase master -i
    git push -f
    ```

### 发布新版本

在master分支上，当当前版本所有的特性和已知bug都已修复，运行
```shell
git fetch --tags
# 选择发布版本的粒度，参见semver语义化版本规则
npm version major|minor|patch
git push --follow-tags origin master
```

tag push到gitlab之后，ci会执行以下脚本，无需在本地执行。
```
npm run build:tui
npm run publish:tui
```

### 版本约定

目前tdc-ui还处于开发中，不稳定。兼容的改进，或者不对tdc-ui本身产生巨大变化（比如样式）的提交，一律打patch，否则打minor。下游依赖通过`~0.x`来确定tdc-ui在某个minor版本。比如`~0.3`会约束依赖的版本在`0.3`到 `0.4`之间。
 - tdc-ui不发生breaking changes，则会一直打patch，下游依赖只需重新`npm install`就可以。
 - 如果发生breaking changes，tdc-ui则会迭代一个minor版本，下游依赖则需更新版本号到`~0.4`。

## Commit Message Guidelines

CHANGELOG 利用commit messages产生。有规则的commit messages可读性更好，CHANGELOG也会更清楚。

### Commit Message Format
Each commit message consists of a **header**, a **body**(optional) and a **footer**(optional).  The header has a special
format that includes a **type**, a **scope** and a **subject**:

```
<type>(<scope>): <subject>
<BLANK LINE>
<body>
<BLANK LINE>
<footer>
```

The **header** is mandatory and the **scope** of the header is optional.

Any line of the commit message cannot be longer 100 characters! This allows the message to be easier
to read on GitHub as well as in various git tools.

### Revert
If the commit reverts a previous commit, it should begin with `revert: `, followed by the header of
the reverted commit. In the body it should say: `This reverts commit <hash>.`, where the hash is
the SHA of the commit being reverted.

### Type
Must be one of the following:

* **feat**: A new feature
* **fix**: A bug fix
* **docs**: Documentation only changes
* **style**: Changes that do not affect the meaning of the code (white-space, formatting, missing
  semi-colons, etc)
* **refactor**: A code change that neither fixes a bug nor adds a feature
* **perf**: A code change that improves performance
* **test**: Adding missing tests or correcting existing tests
* **build**: Changes that affect the build system, CI configuration or external dependencies
            (example scopes: gulp, broccoli, npm)
* **chore**: Other changes that don't modify `src` or `test` files

### Scope
The scope could be anything specifying place of the commit change. For example
`datepicker`, `dialog`, etc.

### Subject
The subject contains succinct description of the change:

### Body
Just as in the **subject**, use the imperative, present tense: "change" not "changed" nor "changes".
The body should include the motivation for the change and contrast this with previous behavior.

### Footer
The footer should contain any information about **Breaking Changes** and is also the place to
reference GitHub issues that this commit **Closes**.

**Breaking Changes** should start with the word `BREAKING CHANGE:` with a space or two newlines.
The rest of the commit message is then used for this.

A detailed explanation can be found in this [document][commit-message-format].


## 开发组件

1. clone this repo
2. `npm run doc`
3. 在`src/tui`目录下添加组件已经文档
4. 执行`npm run build:tui`和`npm run build:doc`都需成功

### 测试

1. 对组件编写单元测试
2. `npm test`

### 开发注意事项

1. 在组件目录(src)下不要使用barrel，即一个目录里面用index.ts来export。barrel会使得angular编译器产生的metadata错误。

2. 组件必须定义成模块。非组件的类，helper等最好在`src/index.ts`下export，不然很可能出现aot构建错误。

3. 因为aot不是是纯编译层面的语言限制，所以在编写时会出现`npm run doc`运行的应用跑得很好，而构建aot出错，而且aot出错的报错往往也不友好。建议比较频繁地跑aot构建而确保项目aot构建的健康程度。

## Gitlab CI

### Make base image

基础image为如下地址，由 ci/base/Dockerfile制作得到。改image包含`chrome`和`yarn`.

ci-base-后面的数字为当前环境所用nodeJS的版本，命令中的版本号仅供参考，请根据实际版本更改。

```
docker build . -f ci/base/Dockerfile -t frontend/tdc-ui/build/ci-base-10.16
docker tag frontend/tdc-ui/build/ci-base-10.16 172.16.1.99/frontend/tdc-ui/build/ci-base-10.16:latest
docker push 172.16.1.99/frontend/tdc-ui/build/ci-base-10.16:latest
```

### Make precommit image

参照 ci/Dockerfile制作precommit image。该image包含当前项目所有node依赖，如果项目依赖更改，则需要重新制作并推到`172.16.1.99`私有仓库上。

```
./script/buildCi.sh
```

### gitlab-ci

参照 `gitlab-ci.yml`. precommit测试分别为`build-aot`, `unit-test`。`build-aot`包含`build:tui`和`build:doc`, `build:tui`确保tui库能跑过aot build，但这不保证下游依赖能成功build aot，`build:doc`来保证下游依赖能成功build aot。而`unit-test`保证tui库单元测试成功通过。

